<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<div class="content">
    <div class="container">
    <h1>Info of <?php echo e($user->name); ?></h1>

        <p><a href="<?php echo e(route('admin.user.index')); ?>" class="btn btn-primary">User List</a> 

       <?php if(empty($user)): ?>
            <p class="text-danger">No Data yes.</p>
        <?php else: ?>
            <?php if(!empty($user->profile)): ?>
            <h2>Profile of <?php echo e($user->name); ?></h2>
            <div class="row">
                <label class="col-sm-1 text-primary font-weight-bold">Address</label>
                <div class="col-sm-11">
                    <?php echo e($user->profile->address); ?>

                </div>
            </div>
            <div class="row">
                <label class="col-sm-1 text-primary font-weight-bold">Tel</label>
                <div class="col-sm-11">
                    <?php echo e($user->profile->tel); ?>

                </div>
            </div>
            <div class="row">
                <label class="col-sm-1 text-primary font-weight-bold">Province</label>
                <div class="col-sm-11">
                    <?php echo e($user->profile->province); ?>

                </div>
            </div>
            <?php endif; ?>
        <h2>Post list of <?php echo e($user->name); ?></h2>
        <table class="table table-bordered table-striped">
            <tr>
                <th>ID</th>
                <th>Comment</th>
            </tr>
           <?php $__currentLoopData = $user->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($comment->id); ?></td>
                <td><?php echo e($comment->content); ?></td>
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <h2>Comment list of <?php echo e($user->name); ?></h2>
        <table class="table table-bordered table-striped">
            <tr>
                <th>ID</th>
                <th>Comment</th>
            </tr>
           <?php $__currentLoopData = $user->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($comment->id); ?></td>
                <td><?php echo e($comment->content); ?></td>
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
       <?php endif; ?>
    </div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH /home/vagrant/code/PH39-ex2/resources/views/admin/user_info.blade.php ENDPATH**/ ?>