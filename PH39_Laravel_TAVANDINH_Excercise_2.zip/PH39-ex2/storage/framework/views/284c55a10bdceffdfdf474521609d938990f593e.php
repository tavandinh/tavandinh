<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<div class="content">
    <div class="container">
        <h1>User List</h1>

        <p><a href="<?php echo e(route('admin.user.index')); ?>" class="btn btn-primary">User List</a> 
        <a href="<?php echo e(route('admin.user.findUserAgeGreaterThan20')); ?>" class="btn btn-primary">User age>20</a> 
        <a href="<?php echo e(route('admin.user.findUserBirthdayMonth3')); ?>" class="btn btn-primary">User birthday month = 3</a> 
        <a href="<?php echo e(route('admin.user.findUserProvinceReidfort')); ?>" class="btn btn-primary">User Province=Reidfort</a> 
        <a href="<?php echo e(route('admin.user.updateUserAgeGreaterThan18')); ?>" class="btn btn-primary">Update User age >18</a></p>

       <?php if(empty($users)): ?>
            <p class="text-danger">No Data yes.</p>
        <?php else: ?>
        <table class="table table-bordered table-striped">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Age</th>
                <th>Email</th>
                <th>Password</th>
                <th>birthday</th>
                <th>status</th>
                <th>Address</th>
                <th>Tel</th>
                <th>Province</th>
            </tr>
           <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->age); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->password); ?></td>
                <td><?php echo e($user->birthday); ?></td>
                <td><?php echo e($user->status); ?></td>
                <td><?php echo e($user->address); ?></td>
                <td><?php echo e($user->tel); ?></td>
                <td><?php echo e($user->province); ?></td>
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
       <?php endif; ?>
    </div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH /home/vagrant/code/PH39/resources/views/admin/user_list.blade.php ENDPATH**/ ?>