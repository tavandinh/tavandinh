<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<div class="content">
    <div class="container">
        <h1>User List</h1>

        <p><a href="<?php echo e(route('admin.user.index')); ?>" class="btn btn-primary">User List</a> 

       <?php if(empty($users)): ?>
            <p class="text-danger">No Data yes.</p>
        <?php else: ?>
        <table class="table table-bordered table-striped">
            <tr>
                <th>ID</th>
                <th>Comment</th>
                <th>AllInfo</th>
                <th>Name</th>
                <th>Age</th>
                <th>Email</th>
                <th>Password</th>
                <th>birthday</th>
                <th>status</th>
            </tr>
           <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->id); ?></td>
                <td><a href="<?php echo e(route('admin.user.comment',$user->id)); ?>" class="btn btn-primary">Comment</a> </td>
                <td><a href="<?php echo e(route('admin.user.allInfo',$user->id)); ?>" class="btn btn-primary">All</a> </td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->age); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->password); ?></td>
                <td><?php echo e($user->birthday); ?></td>
                <td><?php echo e($user->status); ?></td>
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
       <?php endif; ?>
    </div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH /home/vagrant/code/PH39-ex2/resources/views/admin/user_list.blade.php ENDPATH**/ ?>