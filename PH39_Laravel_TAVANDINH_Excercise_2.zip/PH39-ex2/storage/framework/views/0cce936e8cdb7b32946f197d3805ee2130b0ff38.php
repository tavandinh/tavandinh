<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<div class="content">
    <div class="container">
    <h1>Comment List of <?php echo e($user->first()->name); ?></h1>

        <p><a href="<?php echo e(route('admin.user.index')); ?>" class="btn btn-primary">User List</a> 

       <?php if(empty($comments)): ?>
            <p class="text-danger">No Data yes.</p>
        <?php else: ?>
        <table class="table table-bordered table-striped">
            <tr>
                <th>ID</th>
                <th>Comment</th>
                <th>User</th>
            </tr>
           <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($comment->id); ?></td>
                <td><?php echo e($comment->content); ?></td>
                <td><a href="<?php echo e(route('admin.comment.user',$comment->id)); ?>" class="btn btn-primary">User</a> </td>
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
       <?php endif; ?>
    </div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH /home/vagrant/code/PH39-ex2/resources/views/admin/user_comment_list.blade.php ENDPATH**/ ?>